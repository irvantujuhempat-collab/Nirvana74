import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Lazy-initialized Gemini AI client
let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is missing.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// API Routes
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", school: "SD Negeri Weninggalih 01", npsn: "20200860" });
});

// AI PBD Analysis endpoint
app.post("/api/pbd/analyze", async (req, res) => {
  try {
    const { prompt, indicators, schoolInfo } = req.body;
    
    const ai = getGenAI();
    const systemInstruction = `Anda adalah Asisten Pakar Perencanaan Berbasis Data (PBD) dan RKJM (Rencana Kerja Jangka Menengah) Kemendikbudristek untuk SD Negeri Weninggalih 01 (NPSN: 20200860, Desa Weninggalih, Kec. Jonggol, Kab. Bogor). 
Tugas Anda adalah memberikan rekomendasi pembenahan berbasis siklus PBD: 
1. Identifikasi (Masalah utama Rapor Pendidikan seperti Literasi, Numerasi, Karakter, Iklim Keamanan Sekolah).
2. Refleksi (Akar masalah utama pembelajaran/kompetensi guru).
3. Benahi (Program aksi nyata RKJM 2026-2030, Kegiatan ARKAS, Waktu, dan Penanggung Jawab).
Berikan jawaban yang terstruktur rapi, profesional, praktis, dan sesuai standar sekolah dasar di Jawa Barat.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt || `Analisis data Rapor Pendidikan dan berikan strategi pembenahan RKJM 2026-2030 untuk SD Negeri Weninggalih 01 dengan indikator: ${JSON.stringify(indicators || {})}`,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({ success: true, result: response.text });
  } catch (err: any) {
    console.error("Gemini API Error:", err);
    res.status(500).json({ success: false, error: err?.message || "Gagal memproses rekomendasi PBD AI" });
  }
});

// XML Word Document builder API
app.post("/api/pbd/generate-xml", (req, res) => {
  try {
    const { monitoringItems, schoolMeta } = req.body;
    
    // Generates valid Word OpenXML string derived from template
    const rowsXml = (monitoringItems || []).map((item: any, index: number) => {
      const isOdd = index % 2 === 0;
      const fillBg = isOdd ? "ebf4ff" : "ffffff";
      return `
      <w:tr>
        <w:tc>
          <w:tcPr>
            <w:tcW w:type="pct" w:w="35"/>
            <w:shd w:val="clear" w:color="auto" w:fill="${fillBg}"/>
          </w:tcPr>
          <w:p>
            <w:pPr>
              <w:spacing w:before="15" w:after="15"/>
              <w:ind w:left="15" w:right="15"/>
            </w:pPr>
            <w:r>
              <w:rPr>
                <w:rFonts w:ascii="Open Sans" w:eastAsia="Open Sans" w:hAnsi="Open Sans"/>
                <w:sz w:val="10"/>
                <w:color w:val="2d3748"/>
              </w:rPr>
              <w:t>${item.kegiatan}</w:t>
            </w:r>
          </w:p>
        </w:tc>
        <w:tc>
          <w:tcPr>
            <w:tcW w:type="pct" w:w="30"/>
            <w:shd w:val="clear" w:color="auto" w:fill="${fillBg}"/>
          </w:tcPr>
          <w:p>
            <w:pPr>
              <w:spacing w:before="15" w:after="15"/>
              <w:ind w:left="15" w:right="15"/>
            </w:pPr>
            <w:r>
              <w:rPr>
                <w:rFonts w:ascii="Open Sans" w:eastAsia="Open Sans" w:hAnsi="Open Sans"/>
                <w:sz w:val="10"/>
                <w:color w:val="2d3748"/>
              </w:rPr>
              <w:t>${item.waktu}</w:t>
            </w:r>
          </w:p>
        </w:tc>
        <w:tc>
          <w:tcPr>
            <w:tcW w:type="pct" w:w="35"/>
            <w:shd w:val="clear" w:color="auto" w:fill="${fillBg}"/>
          </w:tcPr>
          <w:p>
            <w:pPr>
              <w:spacing w:before="15" w:after="15"/>
              <w:ind w:left="15" w:right="15"/>
            </w:pPr>
            <w:r>
              <w:rPr>
                <w:rFonts w:ascii="Open Sans" w:eastAsia="Open Sans" w:hAnsi="Open Sans"/>
                <w:sz w:val="10"/>
                <w:color w:val="2d3748"/>
              </w:rPr>
              <w:t>${item.penanggungJawab}</w:t>
            </w:r>
          </w:p>
        </w:tc>
      </w:tr>`;
    }).join("\n");

    const fullXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    <w:table>
      <w:tr>
        <w:tc>
          <w:tcPr>
            <w:tcW w:type="pct" w:w="35"/>
            <w:shd w:val="clear" w:color="auto" w:fill="ed8b00"/>
          </w:tcPr>
          <w:p>
            <w:pPr>
              <w:jc w:val="center"/>
              <w:spacing w:before="25" w:after="25"/>
            </w:pPr>
            <w:r>
              <w:rPr>
                <w:rFonts w:ascii="Open Sans" w:eastAsia="Open Sans" w:hAnsi="Open Sans"/>
                <w:sz w:val="11"/>
                <w:b/>
                <w:color w:val="ffffff"/>
              </w:rPr>
              <w:t>Kegiatan Evaluasi &amp; Monitoring</w:t>
            </w:r>
          </w:p>
        </w:tc>
        <w:tc>
          <w:tcPr>
            <w:tcW w:type="pct" w:w="30"/>
            <w:shd w:val="clear" w:color="auto" w:fill="ed8b00"/>
          </w:tcPr>
          <w:p>
            <w:pPr>
              <w:jc w:val="center"/>
              <w:spacing w:before="25" w:after="25"/>
            </w:pPr>
            <w:r>
              <w:rPr>
                <w:rFonts w:ascii="Open Sans" w:eastAsia="Open Sans" w:hAnsi="Open Sans"/>
                <w:sz w:val="11"/>
                <w:b/>
                <w:color w:val="ffffff"/>
              </w:rPr>
              <w:t>Waktu</w:t>
            </w:r>
          </w:p>
        </w:tc>
        <w:tc>
          <w:tcPr>
            <w:tcW w:type="pct" w:w="35"/>
            <w:shd w:val="clear" w:color="auto" w:fill="ed8b00"/>
          </w:tcPr>
          <w:p>
            <w:pPr>
              <w:jc w:val="center"/>
              <w:spacing w:before="25" w:after="25"/>
            </w:pPr>
            <w:r>
              <w:rPr>
                <w:rFonts w:ascii="Open Sans" w:eastAsia="Open Sans" w:hAnsi="Open Sans"/>
                <w:sz w:val="11"/>
                <w:b/>
                <w:color w:val="ffffff"/>
              </w:rPr>
              <w:t>Penanggung Jawab</w:t>
            </w:r>
          </w:p>
        </w:tc>
      </w:tr>
      ${rowsXml}
    </w:table>

    <w:p>
      <w:pPr>
        <w:spacing w:before="200" w:after="50"/>
        <w:jc w:val="center"/>
      </w:pPr>
      <w:r>
        <w:rPr>
          <w:rFonts w:ascii="Montserrat" w:eastAsia="Montserrat" w:hAnsi="Montserrat"/>
          <w:sz w:val="24"/>
          <w:szCs w:val="24"/>
          <w:b/>
          <w:color w:val="1a365d"/>
        </w:rPr>
        <w:t>Dokumen ini disahkan dan diberlakukan secara resmi untuk periode Tahun 2026--2030.</w:t>
      </w:r>
    </w:p>

    <w:p>
      <w:pPr>
        <w:spacing w:before="200" w:after="100"/>
        <w:jc w:val="center"/>
      </w:pPr>
      <w:r>
        <w:rPr>
          <w:rFonts w:ascii="Open Sans" w:eastAsia="Open Sans" w:hAnsi="Open Sans"/>
          <w:sz w:val="20"/>
          <w:color w:val="4a5568"/>
        </w:rPr>
        <w:t>---</w:t>
      </w:r>
    </w:p>

    <w:p>
      <w:pPr>
        <w:jc w:val="center"/>
        <w:spacing w:before="50" w:after="50"/>
      </w:pPr>
      <w:r>
        <w:rPr>
          <w:rFonts w:ascii="Open Sans" w:eastAsia="Open Sans" w:hAnsi="Open Sans"/>
          <w:sz w:val="18"/>
          <w:color w:val="a0aec0"/>
        </w:rPr>
        <w:t>Dokumen ini disusun dengan pendekatan Perencanaan Berbasis Data (PBD)</w:t>
      </w:r>
    </w:p>

    <w:p>
      <w:pPr>
        <w:jc w:val="center"/>
        <w:spacing w:before="0" w:after="50"/>
      </w:pPr>
      <w:r>
        <w:rPr>
          <w:rFonts w:ascii="Open Sans" w:eastAsia="Open Sans" w:hAnsi="Open Sans"/>
          <w:sz w:val="18"/>
          <w:color w:val="a0aec0"/>
        </w:rPr>
        <w:t>SD Negeri Weninggalih 01 - NPSN: 20200860</w:t>
      </w:r>
    </w:p>

    <w:p>
      <w:pPr>
        <w:jc w:val="center"/>
        <w:spacing w:before="0" w:after="50"/>
      </w:pPr>
      <w:r>
        <w:rPr>
          <w:rFonts w:ascii="Open Sans" w:eastAsia="Open Sans" w:hAnsi="Open Sans"/>
          <w:sz w:val="18"/>
          <w:color w:val="a0aec0"/>
        </w:rPr>
        <w:t>Desa Weninggalih, Kecamatan Jonggol, Kabupaten Bogor, Provinsi Jawa Barat</w:t>
      </w:r>
    </w:p>
  </w:body>
</w:document>`;

    res.json({ success: true, xml: fullXml });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server SD Negeri Weninggalih 01 running on http://localhost:${PORT}`);
  });
}

startServer();
