import React, { useState } from 'react';
import {
  initialSekolahMeta,
  initialMonitoringItems,
  initialRaporPendidikan,
  initialRKJMPrograms,
} from './data/rkjmData';
import { EvaluasiMonitoringItem, RKJMProgram } from './types';
import { Header } from './components/Header';
import { DashboardPBD } from './components/DashboardPBD';
import { ProgramRKJMExplorer } from './components/ProgramRKJMExplorer';
import { MatriksMonitoring } from './components/MatriksMonitoring';
import { DokumenOfficialPreview } from './components/DokumenOfficialPreview';
import { AIPbdAssistant } from './components/AIPbdAssistant';

export default function App() {
  const [meta] = useState(initialSekolahMeta);
  const [raporItems] = useState(initialRaporPendidikan);
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Interactive state
  const [programs, setPrograms] = useState<RKJMProgram[]>(initialRKJMPrograms);
  const [monitoringItems, setMonitoringItems] = useState<EvaluasiMonitoringItem[]>(initialMonitoringItems);

  // Handlers for RKJM Programs
  const handleAddProgram = (newProg: RKJMProgram) => {
    setPrograms((prev) => [newProg, ...prev]);
  };

  const handleUpdateProgram = (updatedProg: RKJMProgram) => {
    setPrograms((prev) => prev.map((p) => (p.id === updatedProg.id ? updatedProg : p)));
  };

  const handleDeleteProgram = (id: string) => {
    setPrograms((prev) => prev.filter((p) => p.id !== id));
  };

  // Handlers for Monitoring Items
  const handleUpdateMonitoringItem = (updatedItem: EvaluasiMonitoringItem) => {
    setMonitoringItems((prev) => prev.map((item) => (item.id === updatedItem.id ? updatedItem : item)));
  };

  const handleAddMonitoringItem = (newItem: EvaluasiMonitoringItem) => {
    setMonitoringItems((prev) => [...prev, newItem]);
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Official Header & Nav */}
      <Header meta={meta} activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'dashboard' && (
          <DashboardPBD
            raporItems={raporItems}
            meta={meta}
            onNavigateToAssistant={() => setActiveTab('assistant')}
            onNavigateToPrograms={() => setActiveTab('program')}
          />
        )}

        {activeTab === 'program' && (
          <ProgramRKJMExplorer
            programs={programs}
            onAddProgram={handleAddProgram}
            onUpdateProgram={handleUpdateProgram}
            onDeleteProgram={handleDeleteProgram}
          />
        )}

        {activeTab === 'monitoring' && (
          <MatriksMonitoring
            items={monitoringItems}
            onUpdateItem={handleUpdateMonitoringItem}
            onAddItem={handleAddMonitoringItem}
          />
        )}

        {activeTab === 'dokumen' && (
          <DokumenOfficialPreview meta={meta} monitoringItems={monitoringItems} />
        )}

        {activeTab === 'assistant' && (
          <AIPbdAssistant meta={meta} raporItems={raporItems} />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 text-xs py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div>
            <p className="font-semibold text-slate-200">
              © 2026 {meta.namaSekolah} (NPSN: {meta.npsn})
            </p>
            <p className="text-slate-500 mt-0.5">
              Dokumen Rencana Kerja Jangka Menengah (RKJM) &amp; Perencanaan Berbasis Data (PBD) Periode 2026-2030.
            </p>
          </div>
          <div className="text-slate-500">
            Kecamatan Jonggol, Kabupaten Bogor, Jawa Barat
          </div>
        </div>
      </footer>
    </div>
  );
}
