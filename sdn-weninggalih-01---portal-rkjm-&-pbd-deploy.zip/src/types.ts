export type TahunPeriode = 2026 | 2027 | 2028 | 2029 | 2030;

export type StatusKegiatan = 'Belum' | 'Proses' | 'Selesai' | 'Evaluasi';

export type PrioritasPBD =
  | 'A.1 Literasi'
  | 'A.2 Numerasi'
  | 'A.3 Karakter'
  | 'D.4 Iklim Keamanan'
  | 'D.8 Kepemimpinan Pembelajaran'
  | 'E.1 Partisipasi Orang Tua';

export interface RKJMProgram {
  id: string;
  kode: string;
  namaProgram: string;
  kegiatanUtama: string;
  prioritasPbd: PrioritasPBD;
  indikatorKinerja: string;
  targetOutput: string;
  tahun: TahunPeriode;
  waktuPelaksanaan: string;
  penanggungJawab: string;
  anggaranEst: number;
  sumberDana: 'BOS Reguler' | 'BOS Kinerja' | 'Komite' | 'Mandiri Sekolah';
  status: StatusKegiatan;
}

export interface EvaluasiMonitoringItem {
  id: string;
  kegiatan: string;
  waktu: string;
  penanggungJawab: string;
  status: StatusKegiatan;
  catatanHasil?: string;
  tanggalTerakhirDitinjau?: string;
}

export interface RaporPendidikanItem {
  kode: string;
  domain: string;
  indikator: string;
  skorCurrent: number; // 0 - 100
  kategori: 'Sangat Baik' | 'Baik' | 'Sedang' | 'Perlu Intervensi';
  target2026: number;
  target2028: number;
  target2030: number;
  akarMasalah: string;
  rekomendasiBenahi: string;
}

export interface SekolahMeta {
  namaSekolah: string;
  npsn: string;
  alamat: string;
  desa: string;
  kecamatan: string;
  kabupaten: string;
  provinsi: string;
  kepalaSekolah: string;
  nipKepalaSekolah: string;
  ketuaKomite: string;
  pengawasPembina: string;
  periodeRkjm: string;
  jumlahSiswa: number;
  jumlahRombel: number;
  jumlahGuru: number;
}
