import React from 'react';
import { RaporPendidikanItem, SekolahMeta } from '../types';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';
import { TrendingUp, BookOpen, Calculator, HeartHandshake, ShieldAlert, Award, Sparkles, ArrowRight } from 'lucide-react';

interface DashboardPBDProps {
  raporItems: RaporPendidikanItem[];
  meta: SekolahMeta;
  onNavigateToAssistant: () => void;
  onNavigateToPrograms: () => void;
}

export const DashboardPBD: React.FC<DashboardPBDProps> = ({
  raporItems,
  meta,
  onNavigateToAssistant,
  onNavigateToPrograms,
}) => {
  const chartData = raporItems.map((item) => ({
    indikator: item.indikator.length > 20 ? item.indikator.slice(0, 18) + '...' : item.indikator,
    'Capaian Saat Ini': item.skorCurrent,
    'Target 2026': item.target2026,
    'Target 2030': item.target2030,
  }));

  const getKategoriBadge = (kat: string) => {
    switch (kat) {
      case 'Sangat Baik':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Baik':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Sedang':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      default:
        return 'bg-rose-100 text-rose-800 border-rose-200';
    }
  };

  const getIcon = (code: string) => {
    switch (code) {
      case 'A.1': return BookOpen;
      case 'A.2': return Calculator;
      case 'A.3': return HeartHandshake;
      case 'D.4': return ShieldAlert;
      default: return Award;
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-amber-950 text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-slate-700/80 relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
              <Sparkles className="w-3.5 h-3.5" /> Perencanaan Berbasis Data (PBD) 2026-2030
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Ikhtisar Rapor Pendidikan &amp; Target RKJM
            </h2>
            <p className="text-slate-300 text-sm leading-relaxed">
              Analisis capaian mutu pembelajaran <strong className="text-amber-400">{meta.namaSekolah}</strong>. Data ini digunakan Tim Pengembang Sekolah sebagai pijakan penyusunan Rencana Kerja Jangka Menengah (RKJM) dan RKAS.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <button
              onClick={onNavigateToAssistant}
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs sm:text-sm shadow-lg shadow-amber-500/20 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" /> Asisten Rekomendasi PBD AI
            </button>
            <button
              onClick={onNavigateToPrograms}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl text-xs sm:text-sm border border-slate-600 transition-all flex items-center gap-2 cursor-pointer"
            >
              Lihat Program RKJM <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mini Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-700/60">
          <div>
            <div className="text-xs text-slate-400 font-medium">Jumlah Peserta Didik</div>
            <div className="text-xl sm:text-2xl font-bold text-amber-400 mt-0.5">{meta.jumlahSiswa} Siswa</div>
          </div>
          <div>
            <div className="text-xs text-slate-400 font-medium">Rombongan Belajar</div>
            <div className="text-xl sm:text-2xl font-bold text-slate-100 mt-0.5">{meta.jumlahRombel} Rombel</div>
          </div>
          <div>
            <div className="text-xs text-slate-400 font-medium">Pendidik &amp; Tendik</div>
            <div className="text-xl sm:text-2xl font-bold text-slate-100 mt-0.5">{meta.jumlahGuru} Guru</div>
          </div>
          <div>
            <div className="text-xs text-slate-400 font-medium">Prioritas Pembenahan</div>
            <div className="text-xl sm:text-2xl font-bold text-amber-400 mt-0.5">Literasi &amp; Numerasi</div>
          </div>
        </div>
      </div>

      {/* Rapor Pendidikan Indicator Cards Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-amber-600" />
            Capaian Indikator Rapor Pendidikan 2026 vs Target 2030
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {raporItems.map((item) => {
            const Icon = getIcon(item.kode);
            return (
              <div
                key={item.kode}
                className="bg-white rounded-xl p-5 shadow-sm border border-slate-200/80 hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div className="p-2.5 rounded-lg bg-amber-50 text-amber-700 border border-amber-200/60">
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className={`px-2.5 py-1 rounded-md text-xs font-bold border ${getKategoriBadge(item.kategori)}`}>
                      {item.kategori}
                    </span>
                  </div>

                  <div className="mt-3">
                    <div className="text-xs text-slate-500 font-medium uppercase tracking-wider">{item.kode} • {item.domain}</div>
                    <h4 className="text-base font-bold text-slate-900 mt-1">{item.indikator}</h4>
                  </div>

                  {/* Progress Meter */}
                  <div className="mt-4 space-y-1.5">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-600">Skor Saat Ini: <strong className="text-slate-900 font-extrabold">{item.skorCurrent}</strong></span>
                      <span className="text-amber-700">Target 2030: <strong className="font-extrabold">{item.target2030}</strong></span>
                    </div>
                    <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 to-orange-500 rounded-full transition-all duration-500"
                        style={{ width: `${Math.min(100, item.skorCurrent)}%` }}
                      ></div>
                    </div>
                  </div>

                  <div className="mt-4 text-xs bg-slate-50 p-3 rounded-lg border border-slate-200/60 space-y-1.5">
                    <div className="text-slate-700 font-semibold flex items-center gap-1">
                      🔍 Akar Masalah:
                    </div>
                    <p className="text-slate-600 line-clamp-2">{item.akarMasalah}</p>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 font-medium">
                  <span>Target 2026: <strong className="text-slate-800">{item.target2026}</strong></span>
                  <span>Target 2028: <strong className="text-slate-800">{item.target2028}</strong></span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Chart Section */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200/80">
        <h3 className="text-lg font-bold text-slate-900 mb-2">
          Proyeksi Kemajuan Indikator Mutu (2026 - 2030)
        </h3>
        <p className="text-xs text-slate-500 mb-6">
          Grafik perbandingan skor Rapor Pendidikan eksisting dengan target pencapaian bertahap RKJM SD Negeri Weninggalih 01.
        </p>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
              <XAxis dataKey="indikator" tick={{ fontSize: 11, fill: '#64748b' }} interval={0} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
              />
              <Legend wrapperStyle={{ paddingTop: '15px', fontSize: '12px' }} />
              <Bar dataKey="Capaian Saat Ini" fill="#f59e0b" radius={[6, 6, 0, 0]} />
              <Bar dataKey="Target 2026" fill="#3b82f6" radius={[6, 6, 0, 0]} />
              <Bar dataKey="Target 2030" fill="#10b981" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
