import React, { useState } from 'react';
import { RKJMProgram, PrioritasPBD, TahunPeriode, StatusKegiatan } from '../types';
import { Plus, Search, Filter, Edit3, Trash2, Calendar, DollarSign, UserCheck, Tag, CheckCircle2, Clock, AlertCircle } from 'lucide-react';

interface ProgramRKJMExplorerProps {
  programs: RKJMProgram[];
  onAddProgram: (prog: RKJMProgram) => void;
  onUpdateProgram: (prog: RKJMProgram) => void;
  onDeleteProgram: (id: string) => void;
}

export const ProgramRKJMExplorer: React.FC<ProgramRKJMExplorerProps> = ({
  programs,
  onAddProgram,
  onUpdateProgram,
  onDeleteProgram,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTahun, setSelectedTahun] = useState<string>('all');
  const [selectedPrioritas, setSelectedPrioritas] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProgram, setEditingProgram] = useState<RKJMProgram | null>(null);

  // Form State
  const [formData, setFormData] = useState<Partial<RKJMProgram>>({
    kode: 'PBD-NEW-01',
    namaProgram: '',
    kegiatanUtama: '',
    prioritasPbd: 'A.1 Literasi',
    indikatorKinerja: '',
    targetOutput: '',
    tahun: 2026,
    waktuPelaksanaan: 'Semester 1 TA 2026/2027',
    penanggungJawab: 'Tim Pengembang Sekolah',
    anggaranEst: 3000000,
    sumberDana: 'BOS Reguler',
    status: 'Belum',
  });

  const filteredPrograms = programs.filter((p) => {
    const matchesSearch =
      p.namaProgram.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.kegiatanUtama.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.kode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.penanggungJawab.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesTahun = selectedTahun === 'all' || p.tahun.toString() === selectedTahun;
    const matchesPrioritas = selectedPrioritas === 'all' || p.prioritasPbd === selectedPrioritas;

    return matchesSearch && matchesTahun && matchesPrioritas;
  });

  const handleOpenAdd = () => {
    setEditingProgram(null);
    setFormData({
      kode: `PBD-NEW-${Math.floor(100 + Math.random() * 900)}`,
      namaProgram: '',
      kegiatanUtama: '',
      prioritasPbd: 'A.1 Literasi',
      indikatorKinerja: '',
      targetOutput: '',
      tahun: 2026,
      waktuPelaksanaan: 'Semester 1 TA 2026/2027',
      penanggungJawab: 'Tim Pengembang Sekolah',
      anggaranEst: 3500000,
      sumberDana: 'BOS Reguler',
      status: 'Belum',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (p: RKJMProgram) => {
    setEditingProgram(p);
    setFormData(p);
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.namaProgram || !formData.kegiatanUtama) return;

    if (editingProgram) {
      onUpdateProgram({
        ...editingProgram,
        ...(formData as RKJMProgram),
      });
    } else {
      const newProg: RKJMProgram = {
        id: `prog-${Date.now()}`,
        ...(formData as RKJMProgram),
      };
      onAddProgram(newProg);
    }
    setIsModalOpen(false);
  };

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(val);
  };

  const getStatusBadge = (status: StatusKegiatan) => {
    switch (status) {
      case 'Selesai':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'Proses':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'Evaluasi':
        return 'bg-purple-100 text-purple-800 border-purple-300';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-300';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200/80">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-amber-600" /> Matriks Program RKJM (2026-2030)
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Daftar rencana kerja 4 tahunan SD Negeri Weninggalih 01 yang diturunkan dari Perencanaan Berbasis Data (PBD).
            </p>
          </div>

          <button
            onClick={handleOpenAdd}
            className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs sm:text-sm shadow-md shadow-amber-500/20 transition-all flex items-center gap-2 cursor-pointer self-start md:self-auto"
          >
            <Plus className="w-4 h-4" /> Tambah Program RKJM Baru
          </button>
        </div>

        {/* Filter Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Cari program, penanggung jawab..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div>
            <select
              value={selectedTahun}
              onChange={(e) => setSelectedTahun(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer text-slate-700"
            >
              <option value="all">Semua Tahun Pelaksanaan (2026-2030)</option>
              <option value="2026">Tahun 2026</option>
              <option value="2027">Tahun 2027</option>
              <option value="2028">Tahun 2028</option>
              <option value="2029">Tahun 2029</option>
              <option value="2030">Tahun 2030</option>
            </select>
          </div>

          <div>
            <select
              value={selectedPrioritas}
              onChange={(e) => setSelectedPrioritas(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer text-slate-700"
            >
              <option value="all">Semua Domain Prioritas PBD</option>
              <option value="A.1 Literasi">A.1 Literasi</option>
              <option value="A.2 Numerasi">A.2 Numerasi</option>
              <option value="A.3 Karakter">A.3 Karakter</option>
              <option value="D.4 Iklim Keamanan">D.4 Iklim Keamanan</option>
              <option value="D.8 Kepemimpinan Pembelajaran">D.8 Kepemimpinan Pembelajaran</option>
            </select>
          </div>
        </div>
      </div>

      {/* Program Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-900 text-white text-xs font-bold uppercase tracking-wider">
                <th className="py-3.5 px-4">Kode &amp; Tahun</th>
                <th className="py-3.5 px-4">Nama Program &amp; Kegiatan Utama</th>
                <th className="py-3.5 px-4">Prioritas PBD</th>
                <th className="py-3.5 px-4">Penanggung Jawab</th>
                <th className="py-3.5 px-4 text-right">Estimasi Anggaran</th>
                <th className="py-3.5 px-4 text-center">Status</th>
                <th className="py-3.5 px-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs sm:text-sm">
              {filteredPrograms.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    Tidak ditemukan program RKJM yang sesuai kriteria pencarian.
                  </td>
                </tr>
              ) : (
                filteredPrograms.map((prog) => (
                  <tr key={prog.id} className="hover:bg-amber-50/40 transition-colors">
                    <td className="py-4 px-4 align-top">
                      <span className="font-mono font-bold text-amber-700 block text-xs">{prog.kode}</span>
                      <span className="inline-block mt-1 px-2 py-0.5 bg-slate-100 font-bold text-slate-700 rounded text-[11px] border border-slate-200">
                        {prog.tahun}
                      </span>
                    </td>

                    <td className="py-4 px-4 align-top max-w-sm">
                      <div className="font-bold text-slate-900 text-sm">{prog.namaProgram}</div>
                      <p className="text-xs text-slate-600 mt-1 line-clamp-2">{prog.kegiatanUtama}</p>
                      <div className="mt-2 text-[11px] text-slate-500 font-medium flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-400" /> Waktu: {prog.waktuPelaksanaan}
                      </div>
                    </td>

                    <td className="py-4 px-4 align-top">
                      <span className="px-2.5 py-1 bg-amber-100 text-amber-800 rounded-md font-semibold text-xs border border-amber-200 inline-block">
                        {prog.prioritasPbd}
                      </span>
                      <div className="mt-1 text-[11px] text-slate-500">
                        Target: {prog.targetOutput}
                      </div>
                    </td>

                    <td className="py-4 px-4 align-top">
                      <div className="font-medium text-slate-800 flex items-center gap-1">
                        <UserCheck className="w-3.5 h-3.5 text-slate-400" /> {prog.penanggungJawab}
                      </div>
                    </td>

                    <td className="py-4 px-4 align-top text-right">
                      <div className="font-bold text-slate-900">{formatRupiah(prog.anggaranEst)}</div>
                      <span className="text-[10px] uppercase font-semibold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                        {prog.sumberDana}
                      </span>
                    </td>

                    <td className="py-4 px-4 align-top text-center">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-bold border inline-block ${getStatusBadge(prog.status)}`}>
                        {prog.status}
                      </span>
                    </td>

                    <td className="py-4 px-4 align-top text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => handleOpenEdit(prog)}
                          title="Edit Program"
                          className="p-1.5 text-slate-600 hover:text-amber-600 hover:bg-amber-100 rounded-lg transition-all cursor-pointer"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onDeleteProgram(prog.id)}
                          title="Hapus Program"
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-100 rounded-lg transition-all cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">
                {editingProgram ? 'Edit Program RKJM' : 'Tambah Program RKJM Baru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold text-lg p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Kode Program</label>
                  <input
                    type="text"
                    required
                    value={formData.kode || ''}
                    onChange={(e) => setFormData({ ...formData, kode: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Tahun Pelaksanaan</label>
                  <select
                    value={formData.tahun || 2026}
                    onChange={(e) => setFormData({ ...formData, tahun: Number(e.target.value) as TahunPeriode })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  >
                    <option value={2026}>2026</option>
                    <option value={2027}>2027</option>
                    <option value={2028}>2028</option>
                    <option value={2029}>2029</option>
                    <option value={2030}>2030</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Nama Program Utama</label>
                <input
                  type="text"
                  required
                  placeholder="misal: Gerakan Literasi Sekolah & Reading Corner"
                  value={formData.namaProgram || ''}
                  onChange={(e) => setFormData({ ...formData, namaProgram: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Rincian Kegiatan</label>
                <textarea
                  rows={2}
                  required
                  placeholder="Deskripsi langkah konkret pembenahan..."
                  value={formData.kegiatanUtama || ''}
                  onChange={(e) => setFormData({ ...formData, kegiatanUtama: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Prioritas PBD</label>
                  <select
                    value={formData.prioritasPbd || 'A.1 Literasi'}
                    onChange={(e) => setFormData({ ...formData, prioritasPbd: e.target.value as PrioritasPBD })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  >
                    <option value="A.1 Literasi">A.1 Literasi</option>
                    <option value="A.2 Numerasi">A.2 Numerasi</option>
                    <option value="A.3 Karakter">A.3 Karakter</option>
                    <option value="D.4 Iklim Keamanan">D.4 Iklim Keamanan</option>
                    <option value="D.8 Kepemimpinan Pembelajaran">D.8 Kepemimpinan Pembelajaran</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Penanggung Jawab</label>
                  <input
                    type="text"
                    required
                    value={formData.penanggungJawab || ''}
                    onChange={(e) => setFormData({ ...formData, penanggungJawab: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Estimasi Anggaran (Rp)</label>
                  <input
                    type="number"
                    required
                    value={formData.anggaranEst || 0}
                    onChange={(e) => setFormData({ ...formData, anggaranEst: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Sumber Dana</label>
                  <select
                    value={formData.sumberDana || 'BOS Reguler'}
                    onChange={(e) => setFormData({ ...formData, sumberDana: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  >
                    <option value="BOS Reguler">BOS Reguler</option>
                    <option value="BOS Kinerja">BOS Kinerja</option>
                    <option value="Komite">Komite</option>
                    <option value="Mandiri Sekolah">Mandiri Sekolah</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Status Execusi</label>
                  <select
                    value={formData.status || 'Belum'}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as StatusKegiatan })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  >
                    <option value="Belum">Belum</option>
                    <option value="Proses">Proses</option>
                    <option value="Selesai">Selesai</option>
                    <option value="Evaluasi">Evaluasi</option>
                  </select>
                </div>
              </div>

              <div className="pt-4 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-semibold hover:bg-slate-200 transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 text-slate-950 rounded-xl font-bold hover:bg-amber-400 transition-colors shadow-md shadow-amber-500/20"
                >
                  Simpan Program RKJM
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
