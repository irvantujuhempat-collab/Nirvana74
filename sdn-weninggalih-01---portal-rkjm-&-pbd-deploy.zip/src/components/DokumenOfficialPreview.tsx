import React, { useState } from 'react';
import { EvaluasiMonitoringItem, SekolahMeta } from '../types';
import { Download, Copy, Printer, Check, FileText, ShieldCheck, Award } from 'lucide-react';

interface DokumenOfficialPreviewProps {
  meta: SekolahMeta;
  monitoringItems: EvaluasiMonitoringItem[];
}

export const DokumenOfficialPreview: React.FC<DokumenOfficialPreviewProps> = ({
  meta,
  monitoringItems,
}) => {
  const [copied, setCopied] = useState(false);
  const [xmlData, setXmlData] = useState<string>('');
  const [isGeneratingXml, setIsGeneratingXml] = useState(false);

  const generateXmlOnDemand = async () => {
    setIsGeneratingXml(true);
    try {
      const res = await fetch('/api/pbd/generate-xml', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ monitoringItems, schoolMeta: meta }),
      });
      const data = await res.json();
      if (data.success) {
        setXmlData(data.xml);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingXml(false);
    }
  };

  const handleCopyXml = async () => {
    let textToCopy = xmlData;
    if (!textToCopy) {
      setIsGeneratingXml(true);
      try {
        const res = await fetch('/api/pbd/generate-xml', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ monitoringItems, schoolMeta: meta }),
        });
        const data = await res.json();
        if (data.success) {
          textToCopy = data.xml;
          setXmlData(data.xml);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setIsGeneratingXml(false);
      }
    }

    if (textToCopy) {
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleDownloadDoc = () => {
    const htmlContent = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head><title>Dokumen RKJM 2026-2030 - ${meta.namaSekolah}</title>
      <style>
        body { font-family: 'Open Sans', sans-serif; margin: 30px; }
        h1, h2 { font-family: 'Montserrat', sans-serif; color: #1a365d; text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th { background-color: #ed8b00; color: #ffffff; padding: 10px; font-weight: bold; border: 1px solid #d97706; text-align: center; }
        td { padding: 8px 12px; border: 1px solid #cbd5e1; color: #2d3748; font-size: 11pt; }
        tr:nth-child(even) { background-color: #ebf4ff; }
        tr:nth-child(odd) { background-color: #ffffff; }
        .closing { text-align: center; margin-top: 40px; }
        .legal-text { font-family: 'Montserrat', sans-serif; font-size: 14pt; font-weight: bold; color: #1a365d; }
        .sub-text { color: #a0aec0; font-size: 10pt; line-height: 1.5; }
      </style>
      </head>
      <body>
        <h2>RENCANA KERJA JANGKA MENENGAH (RKJM)<br/>DAN MATRIKS MONITORING PBD</h2>
        <h3>${meta.namaSekolah.toUpperCase()} (NPSN: ${meta.npsn})</h3>
        <p style="text-align:center;">Periode: ${meta.periodeRkjm}</p>
        
        <table>
          <thead>
            <tr>
              <th style="width:35%;">Kegiatan Evaluasi &amp; Monitoring</th>
              <th style="width:30%;">Waktu</th>
              <th style="width:35%;">Penanggung Jawab</th>
            </tr>
          </thead>
          <tbody>
            ${monitoringItems.map((item, idx) => `
              <tr style="background-color: ${idx % 2 === 0 ? '#ebf4ff' : '#ffffff'};">
                <td>${item.kegiatan}</td>
                <td style="text-align:center;">${item.waktu}</td>
                <td>${item.penanggungJawab}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <div class="closing">
          <p class="legal-text">Dokumen ini disahkan dan diberlakukan secara resmi untuk periode Tahun 2026--2030.</p>
          <p style="color:#4a5568;">---</p>
          <p class="sub-text">Dokumen ini disusun dengan pendekatan Perencanaan Berbasis Data (PBD)</p>
          <p class="sub-text">${meta.namaSekolah} - NPSN: ${meta.npsn}</p>
          <p class="sub-text">Desa ${meta.desa}, Kecamatan ${meta.kecamatan}, ${meta.kabupaten}, Provinsi ${meta.provinsi}</p>
        </div>
      </body>
      </html>
    `;

    const blob = new Blob(['\ufeff', htmlContent], {
      type: 'application/msword',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Dokumen_Pengesahan_RKJM_${meta.npsn}_2026_2030.doc`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Action Toolbar */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-600" /> Pratinjau Dokumen Pengesahan Resmi (OpenXML)
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Tampilan cetak lembar pengesahan RKJM 2026-2030 SD Negeri Weninggalih 01 berformat standar Microsoft Word.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleCopyXml}
            disabled={isGeneratingXml}
            className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl text-xs sm:text-sm transition-all flex items-center gap-2 cursor-pointer shadow-sm"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            {copied ? 'XML Berhasil Disalin!' : 'Salin Kode OpenXML'}
          </button>

          <button
            onClick={handleDownloadDoc}
            className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs sm:text-sm transition-all flex items-center gap-2 cursor-pointer shadow-md shadow-amber-500/20"
          >
            <Download className="w-4 h-4" /> Unduh Dokumen Word (.doc)
          </button>

          <button
            onClick={() => window.print()}
            className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs sm:text-sm border border-slate-300 transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Printer className="w-4 h-4" /> Cetak
          </button>
        </div>
      </div>

      {/* Simulated Paper Layout Container */}
      <div className="bg-slate-200/80 p-4 sm:p-10 rounded-2xl flex justify-center shadow-inner overflow-x-auto">
        <div className="bg-white w-full max-w-4xl p-8 sm:p-14 rounded-none shadow-2xl border border-slate-300 font-sans text-slate-800 space-y-8 my-2 min-w-[650px]">
          {/* KOP SURAT RESMI */}
          <div className="border-b-4 border-double border-slate-900 pb-4 text-center space-y-1">
            <div className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-700">
              Pemerintah Kabupaten Bogor • Dinas Pendidikan
            </div>
            <div className="text-xs sm:text-sm font-bold uppercase text-slate-700">
              Kecamatan Jonggol
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 uppercase tracking-tight">
              {meta.namaSekolah}
            </h1>
            <p className="text-xs text-slate-600">
              NPSN: {meta.npsn} • Alamat: {meta.alamat}, Desa {meta.desa}, Kec. {meta.kecamatan}, {meta.kabupaten}, {meta.provinsi}
            </p>
          </div>

          {/* TITLE DOKUMEN */}
          <div className="text-center space-y-1">
            <h2 className="text-lg sm:text-xl font-black uppercase text-slate-900 tracking-tight" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              LEMBAR PENGESAHAN MATRIKS MONITORING &amp; RKJM
            </h2>
            <p className="text-xs font-bold text-amber-700 uppercase tracking-widest">
              PERIODE TAHUN 2026 – 2030
            </p>
          </div>

          {/* TABLE MATCHING USER XML EXACTLY */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Matriks Kegiatan Evaluasi &amp; Penanggung Jawab
            </h3>

            <table className="w-full border-collapse border border-slate-300 text-xs sm:text-sm">
              <thead>
                <tr style={{ backgroundColor: '#ed8b00' }} className="text-white font-bold text-center">
                  <th className="py-2.5 px-4 border border-orange-600 w-[35%]">
                    Kegiatan Evaluasi &amp; Monitoring
                  </th>
                  <th className="py-2.5 px-4 border border-orange-600 w-[30%]">
                    Waktu
                  </th>
                  <th className="py-2.5 px-4 border border-orange-600 w-[35%]">
                    Penanggung Jawab
                  </th>
                </tr>
              </thead>
              <tbody>
                {monitoringItems.map((item, idx) => {
                  const isEvenZebra = idx % 2 === 0;
                  const rowBgColor = isEvenZebra ? '#ebf4ff' : '#ffffff';
                  return (
                    <tr key={item.id} style={{ backgroundColor: rowBgColor }}>
                      <td className="py-2.5 px-4 border border-slate-300 font-medium text-slate-800">
                        {item.kegiatan}
                      </td>
                      <td className="py-2.5 px-4 border border-slate-300 text-center text-slate-700 font-semibold">
                        {item.waktu}
                      </td>
                      <td className="py-2.5 px-4 border border-slate-300 font-semibold text-slate-800">
                        {item.penanggungJawab}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* SIGNATURE BLOCK */}
          <div className="pt-8 grid grid-cols-2 gap-8 text-center text-xs sm:text-sm font-sans">
            <div className="space-y-16">
              <div>
                <p className="text-slate-600">Mengetahui,</p>
                <p className="font-bold text-slate-900">Ketua Komite Sekolah</p>
              </div>
              <div>
                <p className="font-bold underline text-slate-900">{meta.ketuaKomite}</p>
                <p className="text-slate-500 text-[11px]">Komite SDN Weninggalih 01</p>
              </div>
            </div>

            <div className="space-y-16">
              <div>
                <p className="text-slate-600">Disahkan di Jonggol, 15 Juli 2026</p>
                <p className="font-bold text-slate-900">Kepala {meta.namaSekolah}</p>
              </div>
              <div>
                <p className="font-bold underline text-slate-900">{meta.kepalaSekolah}</p>
                <p className="text-slate-500 text-[11px]">NIP. {meta.nipKepalaSekolah}</p>
              </div>
            </div>
          </div>

          {/* CLOSING DISCLAIMS MATCHING USER XML INSTRUCTIONS */}
          <div className="pt-10 border-t border-slate-200 text-center space-y-2">
            <p className="text-base sm:text-lg font-bold text-[#1a365d]" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              Dokumen ini disahkan dan diberlakukan secara resmi untuk periode Tahun 2026--2030.
            </p>
            <p className="text-slate-500 font-semibold">---</p>
            <p className="text-xs text-[#a0aec0]">
              Dokumen ini disusun dengan pendekatan Perencanaan Berbasis Data (PBD)
            </p>
            <p className="text-xs text-[#a0aec0] font-semibold">
              {meta.namaSekolah} - NPSN: {meta.npsn}
            </p>
            <p className="text-xs text-[#a0aec0]">
              Desa {meta.desa}, Kecamatan {meta.kecamatan}, {meta.kabupaten}, Provinsi {meta.provinsi}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
