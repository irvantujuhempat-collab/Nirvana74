import React, { useState } from 'react';
import { EvaluasiMonitoringItem, StatusKegiatan } from '../types';
import { Clock, CheckCircle2, UserCheck, AlertCircle, Edit2, FileSpreadsheet, Sparkles, Save } from 'lucide-react';

interface MatriksMonitoringProps {
  items: EvaluasiMonitoringItem[];
  onUpdateItem: (item: EvaluasiMonitoringItem) => void;
  onAddItem: (item: EvaluasiMonitoringItem) => void;
}

export const MatriksMonitoring: React.FC<MatriksMonitoringProps> = ({
  items,
  onUpdateItem,
  onAddItem,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editNote, setEditNote] = useState('');
  const [editStatus, setEditStatus] = useState<StatusKegiatan>('Belum');

  const [newKegiatan, setNewKegiatan] = useState('');
  const [newWaktu, setNewWaktu] = useState('Setiap bulan');
  const [newPJ, setNewPJ] = useState('Tim Pengembang Sekolah');
  const [showAddForm, setShowAddForm] = useState(false);

  const startEdit = (item: EvaluasiMonitoringItem) => {
    setEditingId(item.id);
    setEditNote(item.catatanHasil || '');
    setEditStatus(item.status);
  };

  const saveEdit = (item: EvaluasiMonitoringItem) => {
    onUpdateItem({
      ...item,
      status: editStatus,
      catatanHasil: editNote,
      tanggalTerakhirDitinjau: new Date().toISOString().split('T')[0],
    });
    setEditingId(null);
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKegiatan) return;

    onAddItem({
      id: `eval-${Date.now()}`,
      kegiatan: newKegiatan,
      waktu: newWaktu,
      penanggungJawab: newPJ,
      status: 'Belum',
      catatanHasil: 'Kegiatan evaluasi baru ditambahkan.',
      tanggalTerakhirDitinjau: new Date().toISOString().split('T')[0],
    });

    setNewKegiatan('');
    setShowAddForm(false);
  };

  const getStatusBadge = (status: StatusKegiatan) => {
    switch (status) {
      case 'Selesai':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'Proses':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'Evaluasi':
        return 'bg-purple-100 text-purple-800 border-purple-300';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-300';
    }
  };

  return (
    <div className="space-y-6">
      {/* Intro Card */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200/80">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-200 mb-2">
              <FileSpreadsheet className="w-3.5 h-3.5" /> Struktur Tabel Resmi OpenXML (RKJM)
            </div>
            <h2 className="text-xl font-bold text-slate-900">
              Matriks Evaluasi &amp; Monitoring Kinerja RKJM
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Jadwal pelaksanaan monitoring berkala dan penanggung jawab evaluasi program SD Negeri Weninggalih 01.
            </p>
          </div>

          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl text-xs sm:text-sm transition-all cursor-pointer self-start md:self-auto"
          >
            {showAddForm ? 'Tutup Form' : '+ Tambah Item Evaluasi'}
          </button>
        </div>

        {/* Form Add New Item */}
        {showAddForm && (
          <form onSubmit={handleCreate} className="mt-4 p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3 text-xs sm:text-sm">
            <h4 className="font-bold text-slate-800">Tambah Item Kegiatan Evaluasi &amp; Monitoring</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Nama Kegiatan Evaluasi</label>
                <input
                  type="text"
                  required
                  placeholder="misal: Rapat Audit Internal BOS"
                  value={newKegiatan}
                  onChange={(e) => setNewKegiatan(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Waktu Pelaksanaan</label>
                <input
                  type="text"
                  required
                  placeholder="misal: Akhir semester"
                  value={newWaktu}
                  onChange={(e) => setNewWaktu(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Penanggung Jawab</label>
                <input
                  type="text"
                  required
                  placeholder="misal: Tim Pengembang Sekolah"
                  value={newPJ}
                  onChange={(e) => setNewPJ(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                className="px-4 py-2 bg-amber-500 text-slate-950 font-bold rounded-lg hover:bg-amber-400 transition-colors"
              >
                Simpan Item Evaluasi
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Official Table rendered with exact OpenXML styling match (#ed8b00 orange header, #ebf4ff zebra fill) */}
      <div className="bg-white rounded-2xl shadow-md border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse font-sans">
            <thead>
              <tr style={{ backgroundColor: '#ed8b00' }} className="text-white text-xs sm:text-sm font-bold tracking-wider uppercase border-b border-orange-600">
                <th className="py-4 px-6 text-center w-1/3">Kegiatan Evaluasi &amp; Monitoring</th>
                <th className="py-4 px-6 text-center w-1/4">Waktu</th>
                <th className="py-4 px-6 text-center w-1/3">Penanggung Jawab</th>
                <th className="py-4 px-4 text-center">Status &amp; Opsi</th>
              </tr>
            </thead>
            <tbody className="text-xs sm:text-sm text-slate-800 divide-y divide-slate-200">
              {items.map((item, index) => {
                const isEvenZebra = index % 2 === 0;
                const rowBgColor = isEvenZebra ? '#ebf4ff' : '#ffffff';
                const isEditing = editingId === item.id;

                return (
                  <tr key={item.id} style={{ backgroundColor: rowBgColor }} className="hover:opacity-95 transition-all">
                    {/* Kegiatan */}
                    <td className="py-4 px-6 font-medium text-slate-900 align-top">
                      <div className="text-sm font-bold text-slate-900">{item.kegiatan}</div>
                      {item.catatanHasil && !isEditing && (
                        <p className="text-xs text-slate-600 mt-1 italic bg-white/60 p-2 rounded border border-slate-200/60">
                          &ldquo;{item.catatanHasil}&rdquo;
                        </p>
                      )}
                      {isEditing && (
                        <div className="mt-2">
                          <label className="text-[11px] font-bold text-slate-700 block mb-0.5">Edit Catatan Evaluasi:</label>
                          <input
                            type="text"
                            value={editNote}
                            onChange={(e) => setEditNote(e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs focus:ring-2 focus:ring-amber-500 outline-none"
                          />
                        </div>
                      )}
                    </td>

                    {/* Waktu */}
                    <td className="py-4 px-6 text-center font-medium align-top">
                      <span className="inline-flex items-center gap-1 text-slate-700 font-semibold bg-white/80 px-3 py-1 rounded-full border border-slate-200/80 shadow-2xs">
                        <Clock className="w-3.5 h-3.5 text-amber-600" /> {item.waktu}
                      </span>
                    </td>

                    {/* Penanggung Jawab */}
                    <td className="py-4 px-6 text-center font-semibold text-slate-800 align-top">
                      <span className="inline-flex items-center gap-1.5 text-slate-900">
                        <UserCheck className="w-4 h-4 text-blue-600" /> {item.penanggungJawab}
                      </span>
                    </td>

                    {/* Status & Action */}
                    <td className="py-4 px-4 text-center align-top">
                      {!isEditing ? (
                        <div className="flex flex-col items-center gap-2">
                          <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${getStatusBadge(item.status)}`}>
                            {item.status}
                          </span>
                          <button
                            onClick={() => startEdit(item)}
                            className="px-2.5 py-1 text-xs bg-white hover:bg-slate-100 text-slate-700 font-medium rounded border border-slate-300 transition-all cursor-pointer flex items-center gap-1 shadow-2xs"
                          >
                            <Edit2 className="w-3 h-3" /> Update
                          </button>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center gap-2">
                          <select
                            value={editStatus}
                            onChange={(e) => setEditStatus(e.target.value as StatusKegiatan)}
                            className="px-2 py-1 bg-white border border-slate-300 rounded text-xs font-bold"
                          >
                            <option value="Belum">Belum</option>
                            <option value="Proses">Proses</option>
                            <option value="Selesai">Selesai</option>
                            <option value="Evaluasi">Evaluasi</option>
                          </select>
                          <button
                            onClick={() => saveEdit(item)}
                            className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded transition-all cursor-pointer flex items-center gap-1"
                          >
                            <Save className="w-3 h-3" /> Simpan
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
