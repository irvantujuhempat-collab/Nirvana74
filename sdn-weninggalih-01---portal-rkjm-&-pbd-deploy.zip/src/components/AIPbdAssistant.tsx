import React, { useState } from 'react';
import { RaporPendidikanItem, SekolahMeta } from '../types';
import { Sparkles, Send, Bot, User, BookOpen, Calculator, ShieldAlert, FileText, CheckCircle2, Loader2 } from 'lucide-react';

interface AIPbdAssistantProps {
  meta: SekolahMeta;
  raporItems: RaporPendidikanItem[];
}

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}

export const AIPbdAssistant: React.FC<AIPbdAssistantProps> = ({ meta, raporItems }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: `Sampurasun! Saya **Asisten AI Perencanaan Berbasis Data (PBD)** untuk **SD Negeri Weninggalih 01**.\n\nSaya siap membantu Tim Pengembang Sekolah dan Kepala Sekolah dalam:\n- 📊 Menganalisis Rapor Pendidikan & merumuskan Identifikasi, Refleksi, Benahi (IRB).\n- 📝 Menyusun Rencana Kerja Jangka Menengah (RKJM) 2026-2030.\n- 💰 Merekomendasikan usulan kegiatan Rencana Kerja & Anggaran Sekolah (RKAS).\n\nSilahkan pilih pertanyaan cepat di bawah atau ketikkan pertanyaan Anda!`,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [loading, setLoading] = useState(false);

  const quickPrompts = [
    "Rekomendasi Pembenahan Literasi (A.1) untuk Rombel I-VI",
    "Strategi Peningkatan Numerasi & Pengadaan Alat Peraga Math",
    "Draft Program P5 Berbasis Kearifan Lokal Jonggol Bogor",
    "Jadwal & Panduan Monitoring Evaluasi RKJM 2026-2030",
  ];

  const handleSend = async (customPrompt?: string) => {
    const textToSend = customPrompt || inputPrompt;
    if (!textToSend.trim() || loading) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customPrompt) setInputPrompt('');
    setLoading(true);

    try {
      const res = await fetch('/api/pbd/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToSend,
          indicators: raporItems,
          schoolInfo: meta,
        }),
      });

      const data = await res.json();
      if (data.success) {
        const aiMsg: Message = {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: data.result,
          timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages((prev) => [...prev, aiMsg]);
      } else {
        throw new Error(data.error);
      }
    } catch (err: any) {
      const errorMsg: Message = {
        id: `err-${Date.now()}`,
        sender: 'ai',
        text: `⚠️ Maaf, terjadi kendala saat merumuskan rekomendasi: ${err.message || 'Gagal menghubungi server AI'}.`,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-600 via-orange-600 to-slate-900 text-white rounded-2xl p-6 shadow-xl border border-amber-500/30">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-xs border border-white/20">
            <Sparkles className="w-6 h-6 text-amber-300" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Asisten AI Konsultasi PBD &amp; RKJM 2026-2030</h2>
            <p className="text-xs text-amber-100 mt-0.5">
              Ditenagai Gemini 3.6 Flash • Khusus pendampingan Tim Pengembang Sekolah {meta.namaSekolah}
            </p>
          </div>
        </div>
      </div>

      {/* Quick Prompt Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {quickPrompts.map((qp, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(qp)}
            disabled={loading}
            className="p-3 bg-white rounded-xl border border-slate-200/80 shadow-2xs hover:border-amber-400 hover:shadow-md transition-all text-left group cursor-pointer"
          >
            <div className="text-[11px] font-bold text-amber-600 uppercase tracking-wider mb-1 flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> Ide Pertanyaan #{idx + 1}
            </div>
            <div className="text-xs font-semibold text-slate-800 group-hover:text-amber-700 transition-colors">
              {qp}
            </div>
          </button>
        ))}
      </div>

      {/* Chat Conversation Box */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 overflow-hidden flex flex-col h-[520px]">
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5 text-amber-400" />
            <span className="font-bold text-sm">PBD Genius AI Bot - {meta.namaSekolah}</span>
          </div>
          <span className="text-[11px] bg-amber-500/20 text-amber-300 px-2.5 py-0.5 rounded-full border border-amber-500/30 font-medium">
            Standar Kemendikbudristek
          </span>
        </div>

        {/* Message List */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50/50">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex gap-3 max-w-3xl ${m.sender === 'user' ? 'ml-auto flex-row-reverse' : ''}`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                  m.sender === 'user'
                    ? 'bg-slate-900 text-amber-400'
                    : 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                }`}
              >
                {m.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`p-4 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-2xs ${
                  m.sender === 'user'
                    ? 'bg-amber-500 text-slate-950 font-medium rounded-tr-none'
                    : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none space-y-2'
                }`}
              >
                <div className="whitespace-pre-wrap">{m.text}</div>
                <div
                  className={`text-[10px] mt-2 font-medium ${
                    m.sender === 'user' ? 'text-slate-800 text-right' : 'text-slate-400'
                  }`}
                >
                  {m.timestamp}
                </div>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-3 text-slate-500 text-xs p-2">
              <Loader2 className="w-4 h-4 animate-spin text-amber-600" />
              <span>Gemini sedang menganalisis data Rapor Pendidikan SD Negeri Weninggalih 01...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-slate-200 flex items-center gap-2">
          <input
            type="text"
            placeholder="Tanyakan analisis PBD, program RKJM, atau rekomendasi ARKAS..."
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            disabled={loading}
            className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
          <button
            onClick={() => handleSend()}
            disabled={loading || !inputPrompt.trim()}
            className="p-2.5 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 rounded-xl font-bold transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
